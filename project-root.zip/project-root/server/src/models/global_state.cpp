#include "models/global_state.hpp"
#include <sstream>

GlobalState g_state = {
    // system
    {
        "online",
        "connected",
        "supervision"
    },

    // motor
    {
        "RUN",
        1450,
        1500,
        39.0
    },

    // gouverne
    {
        120.5,
        18.0,
        7.0,
        1,
        50,
        2,
        "CHECK"
    },

    // sensors
    {
        // temperatures
        {
            41,
            43,
            40,
            47
        },

        // pressure
        {
            1.02,
            "bar",
            1,
            "Actif"
        },

        // water
        {
            0,
            "Aucune détection",
            0
        }
    },

    // battery
    {
        78,         // level
        31.0,       // temperature
        12.5,       // batt_i
        27.8,       // batt_u
        29.4,       // batt_uCharge
        22.0,       // batt_uDech
        347.5,      // batt_power
        42.0,       // batt_capacite
        1.18,       // batt_energie
        3.62,       // uelmin
        3.79,       // uelmax
        24.0,       // tmin
        31.0,       // tmax
        "Charge",   // etat
        "Aucune",   // alarme
        "NORMAL",   // bms_state
        3.70,       // uelement1
        3.69,       // uelement2
        3.74,       // uelement3
        3.71        // uelement4
    }
};

std::string GlobalState::system_to_json() const {
    std::ostringstream oss;

    oss << "{"
        << "\"server_status\":\"" << system.server_status << "\","
        << "\"connection_status\":\"" << system.connection_status << "\","
        << "\"mode\":\"" << system.mode << "\""
        << "}";

    return oss.str();
}

std::string GlobalState::motor_to_json() const {
    std::ostringstream oss;

    oss << "{"
        << "\"status\":\"" << motor.status << "\","
        << "\"rpm_actual\":" << motor.rpm_actual << ","
        << "\"rpm_cmd\":" << motor.rpm_cmd << ","
        << "\"temperature\":" << motor.temperature
        << "}";

    return oss.str();
}

std::string GlobalState::gouverne_to_json() const {
    std::ostringstream oss;

    oss << "{"
        << "\"position\":" << gouverne.position << ","
        << "\"vitesse\":" << gouverne.vitesse << ","
        << "\"couple\":" << gouverne.couple << ","
        << "\"statut_word\":" << gouverne.statut_word << ","
        << "\"txpdo_ms\":" << gouverne.txpdo_ms << ","
        << "\"node_id\":" << gouverne.node_id << ","
        << "\"status\":\"" << gouverne.status << "\""
        << "}";

    return oss.str();
}

std::string GlobalState::sensors_to_json() const {
    std::ostringstream oss;

    oss << "{"
        << "\"temperatures\":{"
            << "\"temp_smo1\":" << sensors.temperatures.temp_smo1 << ","
            << "\"temp_smo2\":" << sensors.temperatures.temp_smo2 << ","
            << "\"temp_smo3\":" << sensors.temperatures.temp_smo3 << ","
            << "\"temp_plaque\":" << sensors.temperatures.temp_plaque
        << "},"
        << "\"pressure\":{"
            << "\"value\":" << sensors.pressure.value << ","
            << "\"unit\":\"" << sensors.pressure.unit << "\","
            << "\"state\":" << sensors.pressure.state << ","
            << "\"label\":\"" << sensors.pressure.label << "\""
        << "},"
        << "\"water\":{"
            << "\"state\":" << sensors.water.state << ","
            << "\"label\":\"" << sensors.water.label << "\","
            << "\"value\":" << sensors.water.value
        << "}"
        << "}";

    return oss.str();
}

std::string GlobalState::battery_to_json() const {
    std::ostringstream oss;

    oss << "{"
        << "\"level\":" << battery.level << ","
        << "\"temperature\":" << battery.temperature << ","
        << "\"batt_T\":" << battery.temperature << ","
        << "\"batt_i\":" << battery.batt_i << ","
        << "\"batt_u\":" << battery.batt_u << ","
        << "\"batt_uCharge\":" << battery.batt_uCharge << ","
        << "\"batt_uDech\":" << battery.batt_uDech << ","
        << "\"batt_Power\":" << battery.batt_power << ","
        << "\"batt_Capacite\":" << battery.batt_capacite << ","
        << "\"batt_Energie\":" << battery.batt_energie << ","
        << "\"uelmin\":" << battery.uelmin << ","
        << "\"uelmax\":" << battery.uelmax << ","
        << "\"Tmin\":" << battery.tmin << ","
        << "\"Tmax\":" << battery.tmax << ","
        << "\"etat\":\"" << battery.etat << "\","
        << "\"alarme\":\"" << battery.alarme << "\","
        << "\"BMSstate\":\"" << battery.bms_state << "\","
        << "\"uelement1\":" << battery.uelement1 << ","
        << "\"uelement2\":" << battery.uelement2 << ","
        << "\"uelement3\":" << battery.uelement3 << ","
        << "\"uelement4\":" << battery.uelement4
        << "}";

    return oss.str();
}

std::string GlobalState::to_json() const {
    std::ostringstream oss;

    oss << "{"
        << "\"system\":" << system_to_json() << ","
        << "\"motor\":" << motor_to_json() << ","
        << "\"gouverne\":" << gouverne_to_json() << ","
        << "\"sensors\":" << sensors_to_json() << ","
        << "\"battery\":" << battery_to_json()
        << "}";

    return oss.str();
}