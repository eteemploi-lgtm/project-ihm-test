#include "adapters/libcomm_adapter.hpp"

bool LibCommAdapter::init() {
    return true;
}

bool LibCommAdapter::send_frame(const CanFrame& frame) {
    (void)frame;
    return true;
}

bool LibCommAdapter::receive_frame(CanFrame& frame) {
    static int counter = 0;
    counter++;

    if (counter % 10 == 0) {
        // moteur
        frame.id = 0x181;
        frame.data = {0xAA, 0x05, 39, 1}; // rpm 1450, temp 39, RUN
        return true;
    }

    if (counter % 20 == 0) {
        // 4 capteurs température
        frame.id = 0x182;
        frame.data = {41, 43, 40, 47};
        return true;
    }

    if (counter % 30 == 0) {
        // pression = 1.02 bar -> 102
        frame.id = 0x183;
        frame.data = {102, 0};
        return true;
    }

    if (counter % 40 == 0) {
        // présence eau
        frame.id = 0x184;
        frame.data = {0};
        return true;
    }

    return false;
}