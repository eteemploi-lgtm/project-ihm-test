#include "adapters/libtools_adapter.hpp"

CanFrame LibToolsAdapter::encode_motor_rpm_cmd(int rpm) {
    CanFrame frame;
    frame.id = 0x201;
    frame.data = {
        static_cast<uint8_t>(rpm & 0xFF),
        static_cast<uint8_t>((rpm >> 8) & 0xFF)
    };
    return frame;
}

bool LibToolsAdapter::decode_motor_frame(const CanFrame& frame, DecodedMotorFrame& decoded) {
    if (frame.id != 0x181 || frame.data.size() < 4) {
        return false;
    }

    decoded.rpm_actual = frame.data[0] | (frame.data[1] << 8);
    decoded.temperature = static_cast<double>(frame.data[2]);
    decoded.status_code = frame.data[3];
    return true;
}

bool LibToolsAdapter::decode_temperature_sensors_frame(const CanFrame& frame, DecodedTemperatureSensorsFrame& decoded) {
    if (frame.id != 0x182 || frame.data.size() < 4) {
        return false;
    }

    decoded.temp_smo1 = static_cast<int8_t>(frame.data[0]);
    decoded.temp_smo2 = static_cast<int8_t>(frame.data[1]);
    decoded.temp_smo3 = static_cast<int8_t>(frame.data[2]);
    decoded.temp_plaque = static_cast<int8_t>(frame.data[3]);
    return true;
}

bool LibToolsAdapter::decode_pressure_frame(const CanFrame& frame, DecodedPressureFrame& decoded) {
    if (frame.id != 0x183 || frame.data.size() < 2) {
        return false;
    }

    int raw = frame.data[0] | (frame.data[1] << 8);
    decoded.pressure = raw / 100.0;
    return true;
}

bool LibToolsAdapter::decode_water_frame(const CanFrame& frame, DecodedWaterFrame& decoded) {
    if (frame.id != 0x184 || frame.data.size() < 1) {
        return false;
    }

    decoded.state = frame.data[0] ? 1 : 0;
    return true;
}