#include "adapters/libdevice_adapter.hpp"

// #include "LibDevice_Smo.h"

MotorData LibDeviceAdapter::get_motor_data() {
    MotorData data;

    // appeler ta vraie lib ici
    // ex: LibDevice_Smo_GetRPM()

    data.rpm = 1450;
    data.temperature = 39;
    data.status = "RUN";

    return data;
}