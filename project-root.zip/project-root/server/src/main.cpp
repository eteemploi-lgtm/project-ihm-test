#include "transport/http_server.hpp"
#include "sim/state_simulator.hpp"
#include <iostream>

int main() {
    std::cout << "Starting Device Server..." << std::endl;

    start_state_simulator();
    start_http_server();

    return 0;
}