#include "sim/state_simulator.hpp"
#include "models/global_state.hpp"

#include <thread>
#include <chrono>
#include <cstdlib>
#include <ctime>
#include <algorithm>

extern GlobalState g_state;

static double clamp_double(double value, double min_v, double max_v) {
    return std::max(min_v, std::min(max_v, value));
}

static int clamp_int(int value, int min_v, int max_v) {
    return std::max(min_v, std::min(max_v, value));
}

void start_state_simulator() {
    std::srand(static_cast<unsigned int>(std::time(nullptr)));

    std::thread([]() {
        while (true) {
            // ===== MOTEUR =====
            int rpm_delta = (std::rand() % 81) - 40;          // -40 à +40
            double temp_delta = ((std::rand() % 21) - 10) / 10.0; // -1.0 à +1.0

            g_state.motor.rpm_actual = clamp_int(g_state.motor.rpm_actual + rpm_delta, 1200, 1800);
            g_state.motor.temperature = clamp_double(g_state.motor.temperature + temp_delta, 30.0, 70.0);

            if (g_state.motor.rpm_cmd == 0) {
                g_state.motor.status = "STOP";
                g_state.motor.rpm_actual = 0;
            } else {
                g_state.motor.status = "RUN";
            }

            // ===== GOUVERNE =====
            double pos_delta = ((std::rand() % 21) - 10) / 10.0; // -1.0 à +1.0
            double vit_delta = ((std::rand() % 11) - 5) / 10.0;  // -0.5 à +0.5
            double cpl_delta = ((std::rand() % 11) - 5) / 10.0;  // -0.5 à +0.5

            g_state.gouverne.position = clamp_double(g_state.gouverne.position + pos_delta, -150.0, 150.0);
            g_state.gouverne.vitesse = clamp_double(g_state.gouverne.vitesse + vit_delta, 0.0, 30.0);
            g_state.gouverne.couple = clamp_double(g_state.gouverne.couple + cpl_delta, 0.0, 25.0);

            // statut simple
            g_state.gouverne.status = (g_state.gouverne.statut_word == 0 || g_state.gouverne.statut_word == 1)
                ? "OK"
                : "CHECK";

            // ===== CAPTEURS TEMP =====
            int t1_delta = (std::rand() % 3) - 1;
            int t2_delta = (std::rand() % 3) - 1;
            int t3_delta = (std::rand() % 3) - 1;
            int tp_delta = (std::rand() % 3) - 1;

            g_state.sensors.temperatures.temp_smo1 =
                clamp_int(g_state.sensors.temperatures.temp_smo1 + t1_delta, 30, 80);
            g_state.sensors.temperatures.temp_smo2 =
                clamp_int(g_state.sensors.temperatures.temp_smo2 + t2_delta, 30, 80);
            g_state.sensors.temperatures.temp_smo3 =
                clamp_int(g_state.sensors.temperatures.temp_smo3 + t3_delta, 30, 80);
            g_state.sensors.temperatures.temp_plaque =
                clamp_int(g_state.sensors.temperatures.temp_plaque + tp_delta, 30, 90);

            // ===== CAPTEUR PRESSION =====
            double p_delta = ((std::rand() % 11) - 5) / 100.0; // -0.05 à +0.05
            g_state.sensors.pressure.value =
                clamp_double(g_state.sensors.pressure.value + p_delta, 0.80, 1.30);

            if (g_state.sensors.pressure.value < 1.10) {
                g_state.sensors.pressure.state = 1;
                g_state.sensors.pressure.label = "Actif";
            } else {
                g_state.sensors.pressure.state = 2;
                g_state.sensors.pressure.label = "Élevé";
            }

            // ===== CAPTEUR EAU =====
            // petite chance de détection
            int eau_rand = std::rand() % 20;
            if (eau_rand == 0) {
                g_state.sensors.water.state = 1;
                g_state.sensors.water.value = 1;
                g_state.sensors.water.label = "Eau détectée";
            } else {
                g_state.sensors.water.state = 0;
                g_state.sensors.water.value = 0;
                g_state.sensors.water.label = "Aucune détection";
            }

            // ===== BATTERIE =====
            double batt_temp_delta = ((std::rand() % 11) - 5) / 10.0; // -0.5 à +0.5
            double batt_i_delta = ((std::rand() % 11) - 5) / 10.0;
            double batt_u_delta = ((std::rand() % 11) - 5) / 100.0;

            g_state.battery.temperature =
                clamp_double(g_state.battery.temperature + batt_temp_delta, 20.0, 45.0);

            g_state.battery.batt_i =
                clamp_double(g_state.battery.batt_i + batt_i_delta, 8.0, 18.0);

            g_state.battery.batt_u =
                clamp_double(g_state.battery.batt_u + batt_u_delta, 24.0, 29.0);

            g_state.battery.batt_uCharge =
                clamp_double(g_state.battery.batt_uCharge + batt_u_delta, 26.0, 30.0);

            g_state.battery.batt_uDech =
                clamp_double(g_state.battery.batt_uDech + batt_u_delta, 20.0, 24.0);

            g_state.battery.batt_power =
                clamp_double(g_state.battery.batt_u * g_state.battery.batt_i, 100.0, 500.0);

            g_state.battery.level = clamp_int(g_state.battery.level - 1, 10, 100);

            if (g_state.battery.level <= 10) {
                g_state.battery.level = 100;
            }

            g_state.battery.etat = (g_state.battery.level > 25) ? "Charge" : "Faible";
            g_state.battery.alarme = (g_state.battery.temperature > 40.0) ? "Surchauffe" : "Aucune";
            g_state.battery.bms_state = (g_state.battery.temperature > 40.0) ? "WARN" : "NORMAL";

            // tensions éléments
            g_state.battery.uelement1 = clamp_double(g_state.battery.uelement1 + batt_u_delta / 10.0, 3.50, 3.90);
            g_state.battery.uelement2 = clamp_double(g_state.battery.uelement2 + batt_u_delta / 10.0, 3.50, 3.90);
            g_state.battery.uelement3 = clamp_double(g_state.battery.uelement3 + batt_u_delta / 10.0, 3.50, 3.90);
            g_state.battery.uelement4 = clamp_double(g_state.battery.uelement4 + batt_u_delta / 10.0, 3.50, 3.90);

            // températures disques
            g_state.battery.t1_disque = clamp_double(g_state.battery.t1_disque + batt_temp_delta, 20.0, 50.0);
            g_state.battery.t2_disque = clamp_double(g_state.battery.t2_disque + batt_temp_delta, 20.0, 50.0);

            std::this_thread::sleep_for(std::chrono::milliseconds(1000));
        }
    }).detach();
}