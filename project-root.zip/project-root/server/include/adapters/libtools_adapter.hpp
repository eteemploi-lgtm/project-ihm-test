#pragma once

#include "models/can_frame.hpp"

struct DecodedMotorFrame {
    int rpm_actual;
    double temperature;
    int status_code;
};

struct DecodedTemperatureSensorsFrame {
    int temp_smo1;
    int temp_smo2;
    int temp_smo3;
    int temp_plaque;
};

struct DecodedPressureFrame {
    double pressure;
};

struct DecodedWaterFrame {
    int state;
};

class LibToolsAdapter {
public:
    CanFrame encode_motor_rpm_cmd(int rpm);

    bool decode_motor_frame(const CanFrame& frame, DecodedMotorFrame& decoded);
    bool decode_temperature_sensors_frame(const CanFrame& frame, DecodedTemperatureSensorsFrame& decoded);
    bool decode_pressure_frame(const CanFrame& frame, DecodedPressureFrame& decoded);
    bool decode_water_frame(const CanFrame& frame, DecodedWaterFrame& decoded);
};