#pragma once

#include <string>

struct MotorData {
    int rpm;
    double temperature;
    std::string status;
};

class LibDeviceAdapter {
public:
    MotorData get_motor_data();
};