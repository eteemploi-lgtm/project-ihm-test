#pragma once

#include <string>

struct SystemState {
    std::string server_status;
    std::string connection_status;
    std::string mode;
};

struct MotorState {
    std::string status;
    int rpm_actual;
    int rpm_cmd;
    double temperature;
};

struct GouverneState {
    double position;
    double vitesse;
    double couple;
    int statut_word;
    int txpdo_ms;
    int node_id;
    std::string status;
};

struct TemperatureSensorsState {
    int temp_smo1;
    int temp_smo2;
    int temp_smo3;
    int temp_plaque;
};

struct PressureSensorState {
    double value;
    std::string unit;
    int state;
    std::string label;
};

struct WaterSensorState {
    int state;
    std::string label;
    int value;
};

struct SensorsState {
    TemperatureSensorsState temperatures;
    PressureSensorState pressure;
    WaterSensorState water;
};

struct BatteryState {
    int level;
    double temperature;
    double batt_i;
    double batt_u;
    double batt_uCharge;
    double batt_uDech;
    double batt_power;
    double batt_capacite;
    double batt_energie;
    double uelmin;
    double uelmax;
    double tmin;
    double tmax;
    std::string etat;
    std::string alarme;
    std::string bms_state;
    double uelement1;
    double uelement2;
    double uelement3;
    double uelement4;
};

struct GlobalState {
    SystemState system;
    MotorState motor;
    GouverneState gouverne;
    SensorsState sensors;
    BatteryState battery;

    std::string system_to_json() const;
    std::string motor_to_json() const;
    std::string gouverne_to_json() const;
    std::string sensors_to_json() const;
    std::string battery_to_json() const;
    std::string to_json() const;
};

extern GlobalState g_state;